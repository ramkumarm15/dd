﻿using BankManagementSystem.Data;
using BankManagementSystem.Models;
using BankManagementSystem.Repository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Data;

namespace BankManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Roles = "User")]
    public class TransactionController : ControllerBase
    {
        private readonly ITransactionRepo _authRepo;


        public TransactionController(ITransactionRepo authRepo)
        {
            _authRepo = authRepo;
        }

        [HttpGet]
        [Route("GetAllTransactions")]
        public  async Task<ActionResult> GetTransactionDetailsByUsername(string Username)
        {
            ResponseObject result = await _authRepo.ViewByUsername(Username);
            if (result.Status)
            {
                return Ok(result.Value);
            }
            else
            {
                return BadRequest(result.Message);
            }
        }
    }
}
