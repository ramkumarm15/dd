﻿using BankManagementSystem.Models;

namespace BankManagementSystem.Repository
{
    public interface ITransactionRepo
    {
        public Task<ResponseObject> ViewByUsername(string Username);
    }
}
